<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
	xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
	xmlns:mo="http://schemas.microsoft.com/office/mac/office/2008/main"
	xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
	xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
	xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
	xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
	xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
	xmlns:w10="urn:schemas-microsoft-com:office:word"
	xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
	xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
	xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
	xmlns:v="urn:schemas-microsoft-com:vml"
	xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"
	xmlns:mv="urn:schemas-microsoft-com:mac:vml"
	xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
	xmlns:xhtml="http://www.w3.org/1999/xhtml" version="1.0">
	
	<xsl:output method="xml" indent="yes" />

	<!-- Override the default stylesheet here -->
	<xsl:template match="text()">
	</xsl:template>

  <!-- ********************** Base Template -->
	<xsl:template match="/" xml:space="preserve">
		<w:document>
			<w:body>
				<xsl:apply-templates select="//*[@id='logoImage']" />
				<!-- ...................... BioRAM Header -->
				<w:p>
					<w:pPr>
						<w:jc w:val="center" />
					</w:pPr>
					<w:r>
						<w:rPr>
							<w:b />
							<w:sz w:val="52" />
							<w:szCs w:val="52" />
						</w:rPr>
						<w:t>BioRAM Assessment</w:t>
					</w:r>
				</w:p>
				<!-- ...................... Date -->
				<xsl:apply-templates select="//*[@id='date']" />
				<!-- ...................... Names Header -->
				<w:p>
					<w:r>
						<w:rPr>
							<w:b />
						</w:rPr>
						<w:t>Names</w:t>
					</w:r>
				</w:p>
				<!-- ...................... Names -->
				<xsl:apply-templates select="//*[@id='names']" />
				<!-- ...................... Procedure Header -->
				<w:p>
					<w:r>
						<w:rPr>
							<w:b />
						</w:rPr>
						<w:t>Procedure</w:t>
					</w:r>
				</w:p>
				<!-- ...................... Procedure -->
				<xsl:apply-templates select="//*[@id='procedure']" />
        <w:p><w:r><w:br w:type="page"/></w:r></w:p>       
				<!-- ...................... Results -->
				<xsl:apply-templates select="//*[@id='results']" />
        <!-- ...................... Charts -->
				<xsl:apply-templates select="//*[@id='charts']" />
        <!-- ...................... Response sets -->
				<xsl:apply-templates select="//*[@id='responseSets']" />
			</w:body>
		</w:document>
	</xsl:template>

	<!-- ********************** Names/Procedure -->
	<xsl:template match="//*[@id='names'] | //*[@id='procedure']" xml:space="preserve">
		<w:p>
			<w:pPr>
				<w:ind w:firstLine="720" />
			</w:pPr>
			<w:r>
				<w:t xml:space="preserve"><xsl:value-of select="." /></w:t>
			</w:r>
		</w:p>
	</xsl:template>

	<!-- ********************** Date -->
	<xsl:template match="//*[@id='date']" xml:space="preserve">
		<w:p>
			<w:pPr>
				<w:spacing w:after="1440" />
				<w:jc w:val="center" />
			</w:pPr>
			<w:r>
				<w:t><xsl:value-of select="." /></w:t>
			</w:r>
		</w:p>
	</xsl:template>

  <!-- ********************** Results -->
	<xsl:template match="//*[@id='results']" xml:space="preserve">
		<!-- ...................... Results Header -->
		<w:p>
			<w:pPr>
				<w:ind w:firstLine="720" />
			</w:pPr>
			<w:r>
				<w:rPr>
					<w:b />
				</w:rPr>
				<w:t>Results</w:t>
			</w:r>
		</w:p>
	  <w:tbl>
      
      <!-- Header [title] row -->
      <w:tr>
        <xsl:for-each select="xhtml:table/xhtml:thead/xhtml:tr/xhtml:th">
        <w:tc>
          <w:tcPr>
           <w:vAlign w:val="center" />
            <w:tcBorders>
              <w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>
            </w:tcBorders>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:jc w:val="center"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:b/>
              </w:rPr>
              <w:t><xsl:value-of select="." /></w:t>
            </w:r>
          </w:p>
        </w:tc>
        </xsl:for-each>
      </w:tr>
      
      <!-- Data rows -->
      <xsl:for-each select="xhtml:table/xhtml:tbody/xhtml:tr">
      <w:tr>
        <xsl:for-each select="xhtml:td">
        <w:tc>
          <w:tcPr>
            <w:vAlign w:val="center" />
          </w:tcPr>
          <w:p>
            <xsl:if test="@class='numeric'">
            <w:pPr>
              <w:jc w:val="center"/>
            </w:pPr>
            </xsl:if>
            <w:r>
              <w:t><xsl:value-of select="." /></w:t>
            </w:r>
          </w:p>
        </w:tc>
        </xsl:for-each>
      </w:tr>
      </xsl:for-each>
      
    </w:tbl>
	  <w:p><w:r><w:br w:type="page"/></w:r></w:p>       
	</xsl:template>

	<!-- ********************** Charts -->
	<xsl:template match='//*[@id="charts"]' xml:space="preserve">
		<w:p>
			<w:pPr>
				<w:ind w:firstLine="720" />
			</w:pPr>
			<w:r>
				<w:rPr>
					<w:b />
				</w:rPr>
				<w:t>Charts</w:t>
			</w:r>
		</w:p>

    <w:p><w:r><w:br w:type="page"/></w:r></w:p>       
	</xsl:template>
  
  <!-- ********************** Response Sets -->
  <xsl:template match='//*[@id="responseSets"]' xml:space="preserve">
	<w:p>
		<w:pPr>
			<w:ind w:firstLine="720" />
		</w:pPr>
		<w:r>
			<w:rPr>
				<w:b />
			</w:rPr>
			<w:t>Response Sets</w:t>
		</w:r>
	</w:p>

  <xsl:for-each select="//*[@class='responseSet']">
	<w:tbl>
		<w:tr> 
			<w:tc>
				<w:tcPr>
					<w:gridSpan w:val="3" />
				</w:tcPr>
				<w:p>
					<w:r>
						<w:rPr>
							<w:sz w:val="28" />
							<w:szCs w:val="28" />
						</w:rPr>
						<w:t>
						  <xsl:value-of select="*[@class='responseSetHeader']/*[@class='module']"/>
						  <xsl:text xml:space="preserve"> </xsl:text>
						  <xsl:value-of select="*[@class='responseSetHeader']/*[@class='response-set']"/>
						</w:t>
					</w:r>
				</w:p>
			</w:tc>
		</w:tr>
		
		<!-- Row titles -->
		<w:tr>
		  <xsl:for-each select="xhtml:table/xhtml:thead/xhtml:tr/xhtml:th">
			<w:tc>
        <w:tcPr>
          <w:tcBorders>
            <w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>
          </w:tcBorders>
        </w:tcPr>
				<w:p>
					<w:pPr>
						<w:jc w:val="center" />
					</w:pPr>
					<w:r>
						<w:rPr>
							<w:b />
							<w:sz w:val="20" />
							<w:szCs w:val="20" />
						</w:rPr>
						<w:t><xsl:value-of select="."/></w:t>
					</w:r>
				</w:p>
			</w:tc>
		  </xsl:for-each>
		</w:tr>
		
    <!-- Data -->
    <xsl:for-each select="xhtml:table/xhtml:tbody/xhtml:tr">
		<w:tr>
		  <xsl:for-each select="xhtml:td">
			<w:tc>
			  <xsl:if test="@colspan='3'">
				<w:tcPr>
					<w:gridSpan w:val="3" />
				</w:tcPr>
			  </xsl:if>
				<w:p>
				  <xsl:if test="@class='numeric' or @class='categoryRow'">
					<w:pPr>
						<w:jc w:val="center" />
					</w:pPr>
					</xsl:if>
					<w:r>
					  <xsl:if test="@class='categoryRow'">
						<w:rPr>
							<w:b />
							<w:sz w:val="28" />
							<w:szCs w:val="28" />
						</w:rPr>
						</xsl:if>
						<w:t xml:space="preserve"><xsl:value-of select="."/></w:t>
					</w:r>
				</w:p>
			</w:tc>
		  </xsl:for-each>
		</w:tr>
    </xsl:for-each>
	</w:tbl>
	
  <w:p><w:r><w:br w:type="page"/></w:r></w:p>       
  </xsl:for-each>

</xsl:template>
  
  <!-- ********************** Logo image -->
  <xsl:template match='//*[@id="logoImage"]' xml:space="preserve">
    <w:p>
      <w:pPr>
        <w:jc w:val="center" />
      </w:pPr>
      <w:r>
        <w:drawing>
          <wp:inline>
            <wp:extent cx="5934075" cy="1504950" />
            <wp:docPr id="{position()}" name="Picture 1" />
            <wp:cNvGraphicFramePr>
              <a:graphicFrameLocks
                xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
                noChangeAspect="1" />
            </wp:cNvGraphicFramePr>
            <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
              <a:graphicData
                uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:pic
                  xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                  <pic:nvPicPr>
                    <pic:cNvPr id="0" name="Picture 1" />
                    <pic:cNvPicPr>
                      <a:picLocks noChangeAspect="1" noChangeArrowheads="1" />
                    </pic:cNvPicPr>
                  </pic:nvPicPr>
                  <pic:blipFill>
                    <a:blip r:embed="rel-{xhtml:img/@src}" cstate="print"/>
                    <a:srcRect />
                    <a:stretch>
                      <a:fillRect />
                    </a:stretch>
                  </pic:blipFill>
                  <pic:spPr bwMode="auto">
                    <a:xfrm>
                      <a:off x="0" y="0" />
                      <a:ext cx="5934075" cy="1504950" />
                    </a:xfrm>
                    <a:prstGeom prst="rect">
                      <a:avLst />
                    </a:prstGeom>
                    <a:noFill />
                    <a:ln w="9525">
                      <a:noFill />
                      <a:miter lim="800000" />
                      <a:headEnd />
                      <a:tailEnd />
                    </a:ln>
                  </pic:spPr>
                </pic:pic>
              </a:graphicData>
            </a:graphic>
          </wp:inline>
        </w:drawing>
      </w:r>
    </w:p>
  </xsl:template>
</xsl:stylesheet>