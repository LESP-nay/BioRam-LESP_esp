<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<xsl:stylesheet 
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:xhtml="http://www.w3.org/1999/xhtml" version="1.0">

<xsl:output method="xml" standalone="yes" encoding="utf-8" />

  <!--
    This template's jobs is to create the /word/_rels/document.xml.rels file.
    It scans the XHTML file for <img> tags and extracts their src attribute,
    creating a relationship by the name "rel-<filename>".
   -->
  <xsl:template match="/" xml:space="preserve">
		<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
		  <Relationship Id="rId3" Type="http://schemas.microsoft.com/office/2007/relationships/stylesWithEffects" Target="stylesWithEffects.xml"/>
		  <Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>
		  <Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/webSettings" Target="webSettings.xml"/>
		  <Relationship Id="rId8" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable" Target="fontTable.xml"/>
		  <Relationship Id="rId9" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>
		  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>
		  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
		  
		  <xsl:for-each select="//xhtml:img">
		    <Relationship Id="rel-{@src}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/{@src}"/>
		  </xsl:for-each>
		</Relationships>
  </xsl:template>
</xsl:stylesheet>