/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram;

import gov.sandia.bioram.forms.ResponseForm;
import javax.swing.UIManager;

/**
 *
 * @author danbowe
 */
public class Main {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    java.awt.EventQueue.invokeLater(new Runnable() {

      public void run() {
        try {
          UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
          System.err.println("Error creating default look and feel - " + e.toString());
        }

        new ResponseForm().setVisible(true);
      }
    });
  }
}
