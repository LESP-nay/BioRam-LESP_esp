<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <!--Override the default templates-->
    <xsl:template match="*" />

    <xsl:template match="root">
        <RamModel>
            <ModelInformation>
                <frontHTML><xsl:value-of select="frontMatter" /></frontHTML>
            </ModelInformation>
            <xsl:apply-templates select="modules" />
            <xsl:apply-templates select="resultProfiles" />
            <xsl:apply-templates select="graphs" />
            
        </RamModel>
    </xsl:template>

    <xsl:template match="modules">
        <QuestionModule>
            <QuestionSetRoot>
                <defaultWeight>1.0</defaultWeight>
                <uuid><xsl:value-of select="uuid" /></uuid>
                <title><xsl:value-of select="name" /></title>
                <Children><xsl:apply-templates /></Children>
            </QuestionSetRoot>
        </QuestionModule>
    </xsl:template>

    <xsl:template match="children[ancestor::modules and children]">
        <QuestionSetCategory>
            <defaultWeight>1.0</defaultWeight>
            <uuid><xsl:value-of select="uuid" /></uuid>
            <title><xsl:value-of select="title" /></title>
            <Children><xsl:apply-templates /></Children>
        </QuestionSetCategory>
    </xsl:template>

    <xsl:template match="children[question]">
        <QuestionSetQuestion>
            <defaultWeight>1.0</defaultWeight>
            <uuid><xsl:value-of select="uuid" /></uuid>
            <title><xsl:value-of select="question" /></title>
            <Children />
            <bounds lower="0.0" upper="4.0"/>
            <detailText>
                <xsl:for-each select="suggestions">
                    <xsl:sort select="value" order="descending"/>
                    <xsl:value-of select="value" />
                    <xsl:text> - </xsl:text>
                    <xsl:value-of select="description" />
                    <!--<xsl:if test=". != parent::*/suggestions[last()]">-->
                    <xsl:text>&#xa;</xsl:text>
                    <!--</xsl:if>-->
                </xsl:for-each>
            </detailText>
        </QuestionSetQuestion>
    </xsl:template>

    <xsl:template match="resultProfiles">
        <ResultProfile>
            <uuid><xsl:value-of select="uuid" /></uuid>
            <ResultTitle>
                <title><xsl:value-of select="title" /></title>
                <rawWeight>1.0</rawWeight>
                <normalizeChildren>false</normalizeChildren>
                <Children>
                    <!--A bit of a hack to change the context node so the 
                         module root doesn't become a nonexistant 
                         UUID-referenced category in the Result Profile-->
                    <xsl:for-each select="children[1]">
                        <xsl:apply-templates />
                    </xsl:for-each>
                </Children>
            </ResultTitle>
        </ResultProfile>
    </xsl:template>

    <xsl:template match="children[ancestor::resultProfiles and children]">
        <ResultCategory>
            <categoryUUID><xsl:value-of select="uuid" /></categoryUUID>
            <rawWeight>1.0</rawWeight>
            <normalizeChildren>false</normalizeChildren>
            <Children><xsl:apply-templates /></Children>
        </ResultCategory>
    </xsl:template>

    <xsl:template match="children[weight]">
        <ResultQuestion>
            <questionUUID><xsl:value-of select="uuid" /></questionUUID>
            <rawWeight><xsl:value-of select="weight" /></rawWeight>
        </ResultQuestion>
    </xsl:template>

    <xsl:template match="graphs">
        <Chart>
            <chartTitle><xsl:value-of select="title" /></chartTitle>
            <XAxis>
                <min>0.0</min>
                <max>4.0</max>
                <title><xsl:value-of select="titlex" /></title>
            </XAxis>
            <YAxis>
                <min>0.0</min>
                <max>4.0</max>
                <title><xsl:value-of select="titley" /></title>
            </YAxis>
            <backgroundImagePath>media/<xsl:value-of select="bg" /></backgroundImagePath>
            <xsl:for-each select="datapoints">
                <DataPoint>
                    <legendTitle><xsl:value-of select="title" /></legendTitle>
                    <xResultProfileUUID>
                        <xsl:value-of select="//resultProfiles[1]/uuid" />
                    </xResultProfileUUID>
                    <yResultProfileUUID>
                        <xsl:value-of select="//resultProfiles[1]/uuid" />
                    </yResultProfileUUID>
                </DataPoint>
            </xsl:for-each>
        </Chart>
    </xsl:template>
    

</xsl:stylesheet>

