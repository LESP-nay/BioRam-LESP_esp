@echo off
java -version
echo %ERRORLEVEL%
if %ERRORLEVEL%==0 GOTO :run

if exist "C:\Program Files (x86)\Java\jre6\bin" PATH="C:\Program Files (x86)\Java\jre6\bin"
if exist "C:\Program Files\Java\jre6\bin" PATH="C:\Program Files\Java\jre6\bin"
if exist "C:\Program Files (x86)\Java\jre7\bin" PATH="C:\Program Files (x86)\Java\jre7\bin"
if exist "C:\Program Files\Java\jre7\bin" PATH="C:\Program Files\Java\jre7\bin"

:run

start javaw -jar bioram4.0.3.jar
