if exist "C:\Program Files\Java\jre7\bin" PATH="C:\Program Files\Java\jre7\bin"
if exist "C:\Program Files (x86)\Java\jre7\bin" PATH="C:\Program Files (x86)\Java\jre7\bin"
if exist "C:\Program Files\Java\jre6\bin" PATH="C:\Program Files\Java\jre6\bin"
if exist "C:\Program Files (x86)\Java\jre6\bin" PATH="C:\Program Files (x86)\Java\jre6\bin"

assoc .jar=jarfile
ftype jarfile=%PATH%\javaw.exe -jar "%1" %*
