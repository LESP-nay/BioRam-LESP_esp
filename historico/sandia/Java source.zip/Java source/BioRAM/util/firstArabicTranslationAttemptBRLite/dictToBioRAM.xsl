<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:output method="xml" indent="yes"/>
  <xsl:template match="text()"/>
  <xsl:template match="/">
    <RamModel>
      <QuestionModule>
        <QuestionSetRoot>
          <defaultWeight>1.0</defaultWeight>
          <uuid/>
          <title>Facility</title>
          <Children>
            <xsl:apply-templates/>
          </Children>
        </QuestionSetRoot>
      </QuestionModule>
    </RamModel>
  </xsl:template>
  <xsl:template match="category">
    <QuestionSetCategory>
      <defaultWeight>1.0</defaultWeight>
      <uuid/>
      <title>
        <xsl:value-of select="."/>
      </title>
      <Children/>
    </QuestionSetCategory>
  </xsl:template>
  <xsl:template match="question">
    <QuestionSetQuestion>
      <defaultWeight>1.0</defaultWeight>
      <uuid/>
      <title>
        <xsl:value-of select="."/>
      </title>
      <Children/>
      <detailText>
        <xsl:value-of select="following-sibling::sugg[1]"/>
      </detailText>
      <bounds lower="0.0" upper="4.0"/>
    </QuestionSetQuestion>
  </xsl:template>
</xsl:stylesheet>
